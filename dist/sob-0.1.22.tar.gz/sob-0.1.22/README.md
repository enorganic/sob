# sob

This library is intended as a framework for serializing/de-serializing JSON/YAML into python class instances and vice 
versa.